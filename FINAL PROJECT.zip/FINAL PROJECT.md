Vedant Punit + Jason Lanka (Group 27 Name: Bang Bang)

Introduction:

Which neighborhood in Pittsburgh is best for transportation?
For this project, we wanted to find out which neighborhood in Pittsburgh has the best transportation system. To do this, we looked at three main things: how many POGOH bike docks there are, how many parking spaces, and how many crosswalks are in each neighborhood. We chose these features because they help show how easy it is to get around without a car. Our approach was to clean and organize the data, group it by neighborhood, and then add up the numbers for each type of transportation. We tried to make a simple score or metric by combining these totals, which helped us compare neighborhoods more easily. At first, we thought about using other data like traffic levels or sidewalk quality, but those weren’t available in our datasets. In the end, we focused on the data we had and used bar charts and rankings to figure out which neighborhoods were the most accessible.

The Metric:

For this project, we created a simple way to measure how easy it is to get around in different neighborhoods in Pittsburgh. We looked at three main things: Parking spots, POGOH bike docks for biking, and crosswalks. We counted how many POGOH bike docks each neighborhood had to see which ones are more bike friendly. We also looked at how many crosswalks were in each area to understand how easy it for mobility. Finally, we looked at parking spaces to see how good each neighborhood is for parking. By adding up these three features, we made a score that helped us compare neighborhoods and figure out which ones have the best transportation options.

The Best Neighborhood

POGOH docks: I looked at how many POGOH bike docks there are in different neighborhoods across Pittsburgh. I counted the total number of docks in each neighborhood. I found out which neighborhood had the most docks and made a bar chart to show the top neighborhoods. The results showed that places like Central Oakland and North Oakland have a lot more docks compared to areas like Spring Hill, which had very few. This gave a clear picture of where bike transportation is more available in the city.


```python
import matplotlib.pyplot as plt
import pandas as pd

pogoh = pd.read_csv("Pogoh1.csv")

pogoh['Neighborhoods'] = pogoh['Neighborhoods'].str.strip()

neighborhood_docks = pogoh.groupby('Neighborhoods')['Total_Docks'].sum().reset_index()

top_15 = neighborhood_docks.sort_values(by='Total_Docks', ascending=False).head(15)

for index, row in neighborhood_docks.iterrows():
    print(f"Total docks in {row['Neighborhoods']}: {row['Total_Docks']}")

plt.figure(figsize=(10, 6))
plt.bar(top_15['Neighborhoods'], top_15['Total_Docks'], color='black', width=0.3)
plt.xlabel("Neighborhoods")
plt.ylabel("Total Number of Docks")
plt.title("Top 15 Neighborhoods by POGOH Docks")
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

```

    Total docks in Allegeney West: 19
    Total docks in Bloomfield: 45
    Total docks in Central Lawrenceville: 17
    Total docks in Central NorthSide: 38
    Total docks in Central Oakland: 122
    Total docks in Chateau: 18
    Total docks in CrawFord Roberts: 19
    Total docks in Downtown: 98
    Total docks in East Liberty: 15
    Total docks in Garfield: 15
    Total docks in HazelWood: 38
    Total docks in Homewood North: 15
    Total docks in Homewood South: 30
    Total docks in Larimer: 34
    Total docks in Lower Lawrenceville: 15
    Total docks in Middle Hill: 34
    Total docks in North Oakland: 126
    Total docks in North Shore: 23
    Total docks in Point breeze North: 19
    Total docks in ShadySide: 83
    Total docks in South Oakland: 38
    Total docks in South Shore: 30
    Total docks in South Side Flats: 61
    Total docks in Spring Hill: 15
    Total docks in Strip District: 66
    Total docks in Upper Lawrenceville: 19
    Total docks in West Oakland: 23



    
![png](output_7_1.png)
    


Top Neighborhoods with POGOH docks:
North Oakland
Central Oakland
Downtown
Shadyside
Strip District

How many crosswalks- continental are there in total in this dataset. And in which neighbrohood are the crossswalks in?
Listed the crosswalks-continental and which neighborhood they are i
After finding out how many crosswalks-continental are there in total in the datasets and which neighborhood it is in.
Found the neighborhood that has the most crosswalks-continental. (Added a column that counts the number of occurrences of each neighborhood)n.


```python
import pandas as pd
import matplotlib.pyplot as plt


chip = pd.read_csv("dataset.tsv", sep="\t")

continental_crosswalks = chip.query("type == 'Crosswalk - Continental'")

# Total count of continental crosswalks
total_continental_crosswalks = len(continental_crosswalks)

neighborhood_counts = (
    continental_crosswalks['neighborhood']
    .value_counts()
    .rename_axis('neighborhood')
    .reset_index(name='count')
)

top15 = neighborhood_counts.head(15)

plt.figure(figsize=(12, 8))
plt.bar(top15['neighborhood'], top15['count'], color='blue')
plt.title('Number of Continental Crosswalks per Neighborhood')
plt.xlabel('Neighborhood')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

print("Total number of continental crosswalks:", total_continental_crosswalks)
print(neighborhood_counts)

```


    
![png](output_10_0.png)
    


    Total number of continental crosswalks: 703
                     neighborhood  count
    0               North Oakland     72
    1   Central Business District     66
    2                   Shadyside     34
    3             Central Oakland     32
    4         Squirrel Hill North     29
    5                     Carrick     28
    6                   Brookline     27
    7         Squirrel Hill South     24
    8                   Overbrook     24
    9                East Liberty     22
    10             Strip District     22
    11                 Bloomfield     21
    12      Central Lawrenceville     21
    13             East Allegheny     19
    14                  Hazelwood     18
    15               Point Breeze     18
    16         Point Breeze North     17
    17                     Esplen     15
    18                      Bluff     14
    19               West Oakland     13
    20        Lower Lawrenceville     12
    21              Regent Square     11
    22                 Greenfield     10
    23                 Banksville      9
    24        Upper Lawrenceville      9
    25           Mount Washington      8
    26              South Oakland      8
    27              Highland Park      7
    28           South Side Flats      6
    29                Morningside      6
    30                  Troy Hill      6
    31                       Hays      5
    32      Spring Hill-City View      5
    33           Brighton Heights      5
    34                    Bon Air      5
    35                    Larimer      5
    36              Homewood West      4
    37                 Upper Hill      4
    38           Allegheny Center      3
    39   Lincoln-Lemington-Belmar      3
    40                 East Hills      3
    41                    Chateau      2
    42                  Beechview      2
    43            Terrace Village      2
    44                   Garfield      2
    45           Duquesne Heights      2
    46                 Friendship      2
    47                Beltzhoover      2
    48                Polish Hill      2
    49       California-Kirkbride      2
    50         Marshall-Shadeland      2
    51          Central Northside      2
    52                    Elliott      1
    53             Homewood North      1
    54              Lincoln Place      1
    55                   Westwood      1
    56              New Homestead      1
    57                    Oakwood      1
    58                 Manchester      1
    59                Perry North      1


The top five neighborhoods with the most crosswalks are...

North Oakland
Central Business District
Shadyside
Central Oakland
Squirrel Hill North


```python
import pandas as pd


parkingSpots = pd.read_csv("ParkingSpots.csv")
parkingSpots.head(60)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>_id</th>
      <th>zone</th>
      <th>start</th>
      <th>end</th>
      <th>utc_start</th>
      <th>meter_transactions</th>
      <th>meter_payments</th>
      <th>mobile_transactions</th>
      <th>mobile_payments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>421 - NorthSide</td>
      <td>2018-01-01T00:20:00</td>
      <td>2018-01-01T00:30:00</td>
      <td>2018-01-01T05:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>403 - Uptown</td>
      <td>2018-01-01T01:10:00</td>
      <td>2018-01-01T01:20:00</td>
      <td>2018-01-01T06:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>412 - East Liberty</td>
      <td>2018-01-01T01:10:00</td>
      <td>2018-01-01T01:20:00</td>
      <td>2018-01-01T06:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>421 - NorthSide</td>
      <td>2018-01-01T01:20:00</td>
      <td>2018-01-01T01:30:00</td>
      <td>2018-01-01T06:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>402 - Downtown 2</td>
      <td>2018-01-01T06:00:00</td>
      <td>2018-01-01T06:10:00</td>
      <td>2018-01-01T11:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>16.25</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>405 - Lawrenceville</td>
      <td>2018-01-01T06:00:00</td>
      <td>2018-01-01T06:10:00</td>
      <td>2018-01-01T11:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>412 - East Liberty</td>
      <td>2018-01-01T06:30:00</td>
      <td>2018-01-01T06:40:00</td>
      <td>2018-01-01T11:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>413 - Squirrel Hill</td>
      <td>2018-01-01T06:30:00</td>
      <td>2018-01-01T06:40:00</td>
      <td>2018-01-01T11:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T06:40:00</td>
      <td>2018-01-01T06:50:00</td>
      <td>2018-01-01T11:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>2.75</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>335 - Friendship Cedarville Lot</td>
      <td>2018-01-01T06:50:00</td>
      <td>2018-01-01T07:00:00</td>
      <td>2018-01-01T11:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>34.25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>406 - Bloomfield (On-street)</td>
      <td>2018-01-01T07:00:00</td>
      <td>2018-01-01T07:10:00</td>
      <td>2018-01-01T12:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T07:20:00</td>
      <td>2018-01-01T07:30:00</td>
      <td>2018-01-01T12:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>5.25</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>335 - Friendship Cedarville Lot</td>
      <td>2018-01-01T07:30:00</td>
      <td>2018-01-01T07:40:00</td>
      <td>2018-01-01T12:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>12.00</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>402 - Downtown 2</td>
      <td>2018-01-01T07:30:00</td>
      <td>2018-01-01T07:40:00</td>
      <td>2018-01-01T12:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>19.50</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>406 - Bloomfield (On-street)</td>
      <td>2018-01-01T07:30:00</td>
      <td>2018-01-01T07:40:00</td>
      <td>2018-01-01T12:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.00</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>413 - Squirrel Hill</td>
      <td>2018-01-01T07:40:00</td>
      <td>2018-01-01T07:50:00</td>
      <td>2018-01-01T12:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>321 - Beacon Bartlett Lot</td>
      <td>2018-01-01T07:50:00</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T12:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>406 - Bloomfield (On-street)</td>
      <td>2018-01-01T07:50:00</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T12:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>409 - Oakland 3</td>
      <td>2018-01-01T07:50:00</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T12:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>7.50</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T07:50:00</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T12:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>6.00</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>325 - JCC/Forbes Lot</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T13:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.00</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>404 - Strip Disctrict</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T13:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>406 - Bloomfield (On-street)</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T13:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.00</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>421 - NorthSide</td>
      <td>2018-01-01T08:00:00</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T13:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>401 - Downtown 1</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T13:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>403 - Uptown</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T13:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>421 - NorthSide</td>
      <td>2018-01-01T08:10:00</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T13:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>10.00</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>304 - Tamello Beatty Lot</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T13:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>9.25</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>325 - JCC/Forbes Lot</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T13:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>344 - 18th &amp; Carson Lot</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T13:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>411 - Shadyside</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T13:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>6.00</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T08:20:00</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T13:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.50</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>357 - Shiloh Street Lot</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T13:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>9.50</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>401 - Downtown 1</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T13:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.00</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>411 - Shadyside</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T13:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>421 - NorthSide</td>
      <td>2018-01-01T08:30:00</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T13:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>325 - JCC/Forbes Lot</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T13:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>341 - 18th &amp; Sidney Lot</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T13:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>8.50</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>407 - Oakland 1</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T13:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>12.00</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>411 - Shadyside</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T13:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.35</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>412 - East Liberty</td>
      <td>2018-01-01T08:40:00</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T13:40:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.75</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>404 - Strip Disctrict</td>
      <td>2018-01-01T08:50:00</td>
      <td>2018-01-01T09:00:00</td>
      <td>2018-01-01T13:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>42</th>
      <td>43</td>
      <td>401 - Downtown 1</td>
      <td>2018-01-01T09:00:00</td>
      <td>2018-01-01T09:10:00</td>
      <td>2018-01-01T14:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>6.00</td>
    </tr>
    <tr>
      <th>43</th>
      <td>44</td>
      <td>341 - 18th &amp; Sidney Lot</td>
      <td>2018-01-01T09:10:00</td>
      <td>2018-01-01T09:20:00</td>
      <td>2018-01-01T14:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>8.00</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>403 - Uptown</td>
      <td>2018-01-01T09:20:00</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T14:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46</td>
      <td>411 - Shadyside</td>
      <td>2018-01-01T09:20:00</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T14:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T09:20:00</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T14:20:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.50</td>
    </tr>
    <tr>
      <th>47</th>
      <td>48</td>
      <td>405 - Lawrenceville</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T09:40:00</td>
      <td>2018-01-01T14:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>48</th>
      <td>49</td>
      <td>406 - Bloomfield (On-street)</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T09:40:00</td>
      <td>2018-01-01T14:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>6.00</td>
    </tr>
    <tr>
      <th>49</th>
      <td>50</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T09:30:00</td>
      <td>2018-01-01T09:40:00</td>
      <td>2018-01-01T14:30:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>328 - Ivy Bellefonte Lot</td>
      <td>2018-01-01T09:50:00</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T14:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.50</td>
    </tr>
    <tr>
      <th>51</th>
      <td>52</td>
      <td>404 - Strip Disctrict</td>
      <td>2018-01-01T09:50:00</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T14:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.25</td>
    </tr>
    <tr>
      <th>52</th>
      <td>53</td>
      <td>411 - Shadyside</td>
      <td>2018-01-01T09:50:00</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T14:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.50</td>
    </tr>
    <tr>
      <th>53</th>
      <td>54</td>
      <td>413 - Squirrel Hill</td>
      <td>2018-01-01T09:50:00</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T14:50:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>54</th>
      <td>55</td>
      <td>328 - Ivy Bellefonte Lot</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T15:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.00</td>
    </tr>
    <tr>
      <th>55</th>
      <td>56</td>
      <td>343 - 19th &amp; Carson Lot</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T15:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.00</td>
    </tr>
    <tr>
      <th>56</th>
      <td>57</td>
      <td>403 - Uptown</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T15:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>57</th>
      <td>58</td>
      <td>412 - East Liberty</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T15:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>3.00</td>
    </tr>
    <tr>
      <th>58</th>
      <td>59</td>
      <td>415 - SS &amp; SSW</td>
      <td>2018-01-01T10:00:00</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T15:00:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>4.50</td>
    </tr>
    <tr>
      <th>59</th>
      <td>60</td>
      <td>325 - JCC/Forbes Lot</td>
      <td>2018-01-01T10:10:00</td>
      <td>2018-01-01T10:20:00</td>
      <td>2018-01-01T15:10:00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>5.50</td>
    </tr>
  </tbody>
</table>
</div>




```python
parkingSpots.columns = parkingSpots.columns.str.strip()

subset = parkingSpots.head(60)

if 'zone' in subset.columns:
    unique_items = subset['zone'].unique()
    total_unique_items = len(unique_items)
    
    print(f"Number of unique items in first 60 rows: {total_unique_items}")
    
    item_counts = subset['zone'].value_counts()
    print(item_counts)
else:
    print("Error: 'zone' column not found. Available columns are:")
    print(subset.columns)

```

    Number of unique items in first 60 rows: 22
    zone
    415 - SS & SSW                     7
    421 - NorthSide                    5
    406 - Bloomfield (On-street)       5
    411 - Shadyside                    5
    412 - East Liberty                 4
    403 - Uptown                       4
    325 - JCC/Forbes Lot               4
    401 - Downtown 1                   3
    413 - Squirrel Hill                3
    404 - Strip Disctrict              3
    405 - Lawrenceville                2
    402 - Downtown 2                   2
    341 - 18th & Sidney Lot            2
    335 - Friendship Cedarville Lot    2
    328 - Ivy Bellefonte Lot           2
    321 - Beacon Bartlett Lot          1
    409 - Oakland 3                    1
    304 - Tamello Beatty Lot           1
    357 - Shiloh Street Lot            1
    344 - 18th & Carson Lot            1
    407 - Oakland 1                    1
    343 - 19th & Carson Lot            1
    Name: count, dtype: int64



```python
import pandas as pd

df = pd.read_csv('ParkingSpots.csv')


zone_counts = df['zone'].value_counts().reset_index()
zone_counts.columns = ['zone', 'Number of Parking Sessions']


zone_counts = zone_counts.sort_values(by='Number of Parking Sessions', ascending=False)


top_60_zones = zone_counts.head(60)


print(top_60_zones)

```

                                   zone  Number of Parking Sessions
    0          328 - Ivy Bellefonte Lot                        5810
    1                    415 - SS & SSW                        5768
    2            322 - Forbes Shady Lot                        5565
    3              325 - JCC/Forbes Lot                        5558
    4      406 - Bloomfield (On-street)                        5500
    5           324 - Forbes Murray Lot                        5418
    6                   421 - NorthSide                        5336
    7                   411 - Shadyside                        5160
    8                   410 - Oakland 4                        5153
    9                      403 - Uptown                        5114
    10                  407 - Oakland 1                        5069
    11          344 - 18th & Carson Lot                        5030
    12                 402 - Downtown 2                        5025
    13                 401 - Downtown 1                        4992
    14                  408 - Oakland 2                        4952
    15            404 - Strip Disctrict                        4907
    16               412 - East Liberty                        4901
    17                  409 - Oakland 3                        4898
    18         304 - Tamello Beatty Lot                        4817
    19              413 - Squirrel Hill                        4659
    20        321 - Beacon Bartlett Lot                        4645
    21          341 - 18th & Sidney Lot                        4522
    22            342 - East Carson Lot                        4497
    23                 422 - Northshore                        4488
    24  335 - Friendship Cedarville Lot                        4475
    25              405 - Lawrenceville                        4345
    26          357 - Shiloh Street Lot                        4215
    27                  419 - Brookline                        4171
    28          338 - 42nd & Butler Lot                        3754
    29          343 - 19th & Carson Lot                        3709
    30             420 - Mt. Washington                        3700
    31      302 - Sheridan Kirkwood Lot                        3698
    32          345 - 20th & Sidney Lot                        3263
    33                    416 - Carrick                        2842
    34       371 - East Ohio Street Lot                        2587
    35       323 - Douglas Phillips Lot                        2521
    36             307 - Eva Beatty Lot                        2418
    37                  418 - Beechview                        2369
    38          334 - Taylor Street Lot                        2277
    39                  425 - Bakery Sq                        1592
    40           424 - Technology Drive                        1573
    41  351 - Brownsville & Sandkey Lot                        1517
    42    355 - Asteroid Warrington Lot                        1436
    43                  417 - Allentown                        1343
    44              426 - Hill District                        1330
    45                414 - Mellon Park                        1311
    46                   423 - West End                        1296
    47          337 - 52nd & Butler Lot                        1294
    48         314 - Penn Circle NW Lot                        1121
    49       301 - Sheridan Harvard Lot                         883
    50          311 - Ansley Beatty Lot                         841
    51         369 - Main/Alexander Lot                         738
    52     375 - Oberservatory Hill Lot                         506
    53              363 - Beechview Lot                         418
    54      354 - Walter/Warrington Lot                         320
    55                  427 - Knoxville                         263
    56              361 - Brookline Lot                         170
    57        331 - Homewood Zenith Lot                         154



```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('ParkingSpots.csv')


zone_counts = df.groupby('zone')['meter_transactions'].sum().reset_index()


zone_counts_top_60 = zone_counts.nlargest(60, 'meter_transactions')


plt.figure(figsize=(10, 6))
plt.bar(zone_counts_top_60['zone'], zone_counts_top_60['meter_transactions'])
plt.xticks(rotation=90)
plt.xlabel('Parking Zones')
plt.ylabel('Number of Parking Sessions (Meter Transactions)')
plt.title('Top 60 Parking Zones by Number of Meter Transactions')
plt.show()

```


    
![png](output_15_0.png)
    


The top 5 Neighborhoods with the most parking sessions is 
- South Side and and South West Side
- Strip District
- Squirell Hill
- Northside 
- Downtown 3


Based on the data collected, The best is North Oakland.

Vedant's conclusion:

Based on the data, I agree that North Oakland stands out as a strong contender for the best neighborhood, especially because of its high number of bike docks and crosswalks. As a college student, transportation access really matters, and being able to easily bike or walk safely around the neighborhood is a huge plus. However, my personal favorite neighborhood is Shadyside. Even though it might not have as many bike docks or crosswalks as North Oakland, I like the vibe there more—it’s quieter, has great coffee shops, and feels more relaxed. So, while I agree with the data’s conclusion from a practical standpoint, my personal preference is shaped more by atmosphere and daily experience.



Jason's conclusion:

The data shows that North Oakland and Central Oakland are strong choices because of their transportation infrastructure, especially with bike docks and crosswalks. From a purely logical perspective, those neighborhoods make a lot of sense as “best” because they’re built for easy, safe movement, which is super helpful for students and city living. That said, my personal favorite neighborhood is the Strip District. It doesn’t rank highest in bike docks or crosswalks, but I like the energy there, with all the markets, food options, and cool street art. The walkability is good enough for me, and I feel like there’s more personality in the area. So, the data points to convenience, but I lean toward neighborhoods that feel more unique.
